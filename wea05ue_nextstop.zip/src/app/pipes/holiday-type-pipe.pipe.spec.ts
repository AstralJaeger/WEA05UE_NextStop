import { HolidayTypePipePipe } from './holiday-type-pipe.pipe';

describe('HolidayTypePipePipe', () => {
  it('create an instance', () => {
    const pipe = new HolidayTypePipePipe();
    expect(pipe).toBeTruthy();
  });
});
