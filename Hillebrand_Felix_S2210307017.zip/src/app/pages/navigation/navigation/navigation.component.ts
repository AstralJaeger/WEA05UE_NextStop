import {Component} from '@angular/core';

@Component({
  selector: 'app-search',
  imports: [],
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.css'
})
export class NavigationComponent {

}
